"""Actions feasibility test: public-domain assets only (Riemann 1863 photo, Hilbert photo, 1859 report)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cards3 import NoteCard
from explain import StairBuild
from engine import Film, Print, BigText, HILITE, WHITE

def build_film(doc):
    film = Film(24.0, fps=30, look="slate")
    film.add(Print("P01", 0, 300, 1500, rot=-2, t_in=0.15, label="BERNHARD RIEMANN · 1863", label_t=0.8))
    film.add(Print("N01", 3000, 300, 1500, rot=-2, t_in=4.0, label="DAVID HILBERT · 1900", label_t=4.5))
    film.add(Print("N02", 6000, 300, 2300, rot=1.0, t_in=8.0, label="BERLIN ACADEMY REPORT · NOV 1859", label_t=8.6))
    film.add(NoteCard(9000, 300, 2340, 1170, 12.0, title="SMOOTH CURVE", lines=["the average"], kind="index", tag="STEP 1", ic="curve", accent=(30,130,160), rot=-1.0, seed=3))
    film.add(StairBuild(9000, 2000, 4800, 1500, 13.0, 15.0, N=50))
    film.add(BigText("TEST", 0, 1500, 600, 20.0, type_on=0.4, rgb=WHITE))
    for t, x, y, z in [(0, 0, 450, .78), (4, 3000, 450, .78), (8, 6000, 450, .7), (12, 9000, 1250, .55), (20, 0, 800, .7), (24, 0, 800, .7)]:
        film.shot(t, x, y, z)
    return film
