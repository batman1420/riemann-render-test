"""Crafted note cards for the cork board: deckled paper, layered shadow, tape or clip, typewriter type, icon."""
import math, random
import skia
from engine import (Item, paint, draw_text, text_width, paper_fill, ramp, ease_out_back, clamp, draw_pin)

KINDS = {
    "index":  dict(base=(251, 237, 212), ink=(26, 26, 26), rule=(150, 175, 205)),
    "kraft":  dict(base=(205, 170, 120), ink=(46, 34, 24), rule=(150, 118, 78)),
    "sticky": dict(base=(250, 226, 110), ink=(48, 40, 20), rule=(210, 185, 80)),
}


def deckle(W, H, seed, amp):
    rnd = random.Random(seed)
    pts = []
    n = 26
    for i in range(n):
        pts.append((-W / 2 + W * i / n, -H / 2 + rnd.uniform(-amp, amp)))
    for i in range(n // 2):
        pts.append((W / 2 + rnd.uniform(-amp, amp), -H / 2 + H * i / (n // 2)))
    for i in range(n):
        pts.append((W / 2 - W * i / n, H / 2 + rnd.uniform(-amp, amp)))
    for i in range(n // 2):
        pts.append((-W / 2 + rnd.uniform(-amp, amp), H / 2 - H * i / (n // 2)))
    p = skia.Path()
    p.moveTo(*pts[0])
    for q in pts[1:]:
        p.lineTo(*q)
    p.close()
    return p


def icon(c, kind, cx, cy, s, rgb, a):
    st = paint(rgb, a, stroke=s * 0.09)
    fl = paint(rgb, a)
    if kind == "in" or kind == "out":
        c.drawRect(skia.Rect.MakeXYWH(cx - s * 0.25, cy - s * 0.3, s * 0.55, s * 0.6), st)
        x0, x1 = (cx - s * 0.7, cx - s * 0.05) if kind == "in" else (cx + s * 0.05, cx + s * 0.7)
        c.drawLine(x0, cy, x1, cy, st)
        d = 1 if kind == "in" else 1
        hx = x1
        c.drawLine(hx - s * 0.16, cy - s * 0.16, hx, cy, st); c.drawLine(hx - s * 0.16, cy + s * 0.16, hx, cy, st)
    elif kind == "zero":
        c.drawOval(skia.Rect.MakeXYWH(cx - s * 0.4, cy - s * 0.4, s * 0.8, s * 0.8), st)
        c.drawLine(cx - s * 0.5, cy + s * 0.5, cx + s * 0.5, cy - s * 0.5, st)
    elif kind == "line":
        c.drawLine(cx, cy - s * 0.6, cx, cy + s * 0.6, st)
        for k in (-0.4, -0.05, 0.3):
            c.drawCircle(cx, cy + s * k, s * 0.1, fl)
        c.drawLine(cx - s * 0.5, cy + s * 0.62, cx + s * 0.5, cy + s * 0.62, paint(rgb, a * 0.6, stroke=s * 0.05))
    elif kind == "wave":
        p = skia.Path(); p.moveTo(cx - s * 0.7, cy)
        for i in range(1, 41):
            x = cx - s * 0.7 + s * 1.4 * i / 40
            p.lineTo(x, cy - math.sin(i / 40 * 6.28 * 2) * s * 0.3)
        c.drawPath(p, st)
    elif kind == "stair":
        p = skia.Path(); p.moveTo(cx - s * 0.6, cy + s * 0.5)
        for k in range(5):
            x = cx - s * 0.6 + k * s * 0.24
            y = cy + s * 0.5 - k * s * 0.22
            p.lineTo(x, y); p.lineTo(x + s * 0.24, y)
        p.lineTo(cx + s * 0.6, cy - s * 0.5)
        c.drawPath(p, st)
    elif kind == "warn":
        p = skia.Path(); p.moveTo(cx, cy - s * 0.55); p.lineTo(cx + s * 0.55, cy + s * 0.45); p.lineTo(cx - s * 0.55, cy + s * 0.45); p.close()
        c.drawPath(p, st)
        c.drawLine(cx, cy - s * 0.2, cx, cy + s * 0.12, st); c.drawCircle(cx, cy + s * 0.29, s * 0.06, fl)
    elif kind == "check":
        p = skia.Path(); p.moveTo(cx - s * 0.5, cy); p.lineTo(cx - s * 0.12, cy + s * 0.38); p.lineTo(cx + s * 0.55, cy - s * 0.4)
        c.drawPath(p, st)
    elif kind == "plus":
        c.drawLine(cx - s * 0.5, cy, cx + s * 0.5, cy, st); c.drawLine(cx, cy - s * 0.5, cx, cy + s * 0.5, st)
    elif kind == "curve":
        p = skia.Path(); p.moveTo(cx - s * 0.6, cy + s * 0.5)
        for i in range(1, 31):
            x = cx - s * 0.6 + s * 1.2 * i / 30
            p.lineTo(x, cy + s * 0.5 - math.sqrt(i / 30) * s)
        c.drawPath(p, st)


class NoteCard(Item):
    z = 12

    def __init__(self, x, y, w, h, t_in, title="", lines=(), kind="index", tag="", ic=None, accent=(176, 30, 26),
                 rot=0.0, t_out=None, z=None, seed=1, title_size=None, body_size=None, sfx=True):
        super().__init__(t_in, t_out, z, sfx)
        self.x, self.y, self.w, self.h, self.rot = x, y, w, h, rot
        self.title, self.lines, self.kind, self.tag, self.ic, self.accent, self.seed = title, list(lines), kind, tag, ic, accent, seed
        self.ts = title_size or h * 0.21
        self.bs = body_size or h * 0.11
        self.path = deckle(w, h, seed, h * 0.007)

    def bounds(self, res):
        r = max(self.w, self.h) * 0.8 + 300
        return skia.Rect.MakeLTRB(self.x - r, self.y - r, self.x + r, self.y + r)

    def cues(self):
        return [("pop", self.t_in, 0.6, {})]

    def fit(self, res, text, size, maxw, font):
        while size > 20 and text_width(res, text, size, font, 0.0) > maxw:
            size *= 0.94
        return size

    def draw(self, c, res, t):
        K = KINDS[self.kind]
        u = ease_out_back(ramp(t, self.t_in, 0.45), 1.2)
        a = ramp(t, self.t_in, 0.15) * self.fade(t)
        if a <= 0:
            return
        W, H = self.w, self.h
        s = 0.92 + 0.08 * u
        c.save(); c.translate(self.x, self.y + (1 - u) * 120); c.rotate(self.rot); c.scale(s, s)
        # layered shadow
        for (dx, dy, bl, al) in ((10, 20, 18, 0.35), (24, 46, 46, 0.30)):
            c.save(); c.translate(dx, dy); c.drawPath(self.path, paint((0, 0, 0), al * a, blur=bl)); c.restore()
        # paper body
        c.drawPath(self.path, paint(K["base"], a))
        c.save(); c.clipPath(self.path, skia.ClipOp.kIntersect, True)
        paper_fill(c, res, skia.Rect.MakeXYWH(-W / 2, -H / 2, W, H), 0.55 * a, 0.5, skia.BlendMode.kMultiply)
        # edge wear: darker inner rim
        c.drawPath(self.path, paint((90, 70, 40), 0.35 * a, stroke=H * 0.03))
        pad = W * 0.07
        # ruled lines on index cards
        if self.kind == "index":
            c.drawRect(skia.Rect.MakeXYWH(-W / 2, -H / 2 + H * 0.17, W, H * 0.012), paint(self.accent, 0.8 * a))
            y = -H / 2 + H * 0.35
            while y < H / 2 - H * 0.08:
                c.drawRect(skia.Rect.MakeXYWH(-W / 2, y, W, H * 0.006), paint(K["rule"], 0.55 * a)); y += H * 0.13
        elif self.kind == "kraft":
            c.drawRect(skia.Rect.MakeXYWH(-W / 2, -H / 2 + H * 0.17, W, H * 0.01), paint(K["rule"], 0.9 * a))
        c.restore()
        # type
        ink = K["ink"]
        iw = 0 if not self.ic else H * 0.34
        maxw = W - 2 * pad - iw
        ty = -H / 2 + H * 0.125
        if self.tag:
            tsz = self.fit(res, self.tag, H * 0.075, W - 2 * pad, "mono")
            draw_text(c, res, self.tag, -W / 2 + pad, ty, tsz, "mono", self.accent, 0.9 * a, 0.12)
        tsz = self.fit(res, self.title, self.ts, maxw, "mono")
        y = -H / 2 + H * 0.17 + tsz * 1.15
        draw_text(c, res, self.title, -W / 2 + pad, y, tsz, "mono", ink, a, 0.0,
                  reveal=len(self.title) * ramp(t, self.t_in + 0.1, 0.5))
        for i, ln in enumerate(self.lines):
            bsz = self.fit(res, ln, self.bs, W - 2 * pad - (iw if i == 0 else 0), "mono")
            y += self.bs * 1.55
            draw_text(c, res, ln, -W / 2 + pad, y, bsz, "mono", ink, 0.85 * a * ramp(t, self.t_in + 0.3 + 0.15 * i, 0.3), 0.0)
        if self.ic:
            icon(c, self.ic, W / 2 - pad - iw * 0.5, H * 0.12, iw * 0.9, self.accent, a * ramp(t, self.t_in + 0.2, 0.3))
        # tape / clip / pin
        if self.kind == "index":
            c.save(); c.translate(0, -H / 2); c.rotate(-3)
            c.drawRect(skia.Rect.MakeXYWH(-W * 0.11, -H * 0.05, W * 0.22, H * 0.11), paint((240, 232, 170), 0.78 * a))
            c.drawRect(skia.Rect.MakeXYWH(-W * 0.11, -H * 0.05, W * 0.22, H * 0.11), paint((150, 130, 60), 0.3 * a, stroke=2))
            c.restore()
        elif self.kind == "kraft":
            c.save(); c.translate(W * 0.28, -H / 2 + 6)
            c.drawRect(skia.Rect.MakeXYWH(-W * 0.05, -H * 0.1, W * 0.1, H * 0.2), paint((40, 40, 44), a))
            c.drawRect(skia.Rect.MakeXYWH(-W * 0.034, -H * 0.1, W * 0.068, H * 0.1), paint((150, 150, 158), 0.8 * a))
            c.restore()
        else:
            draw_pin(c, 0, -H / 2 + H * 0.06, H * 0.045, (176, 30, 26), a)
        c.restore()
