import math
import skia
from engine import Item, ramp, ease_out_cubic, paint, draw_text

def _pi(x):
    return sum(1 for n in range(2, int(x) + 1) if all(n % d for d in range(2, int(n ** .5) + 1)))

def _li(x):
    # smooth approximation of the prime count: integral dt/ln t from 2 (midpoint rule)
    s, n = 0.0, 400
    h = (x - 2) / n
    for i in range(n):
        s += 1 / math.log(2 + (i + .5) * h) * h
    return s

class StairBuild(Item):
    """Animated explainer: smooth curve draws on (t1), then the true prime staircase builds step by step (t3)."""
    z = 20
    def __init__(self, x, y, w, h, t1, t3, t_out=None, N=100):
        super().__init__(t1 - 0.2, t_out, None, False)
        self.x, self.y, self.w, self.h, self.t1, self.t3, self.N = x, y, w, h, t1, t3, N
        self.pts = [(k, _li(k) if k > 2 else 0) for k in range(2, N + 1)]
        self.pm = max(_pi(N), self.pts[-1][1])
        self.primes = [n for n in range(2, N + 1) if all(n % d for d in range(2, int(n ** .5) + 1))]
    def bounds(self, res):
        return skia.Rect.MakeLTRB(self.x - self.w / 2 - 200, self.y - self.h / 2 - 300, self.x + self.w / 2 + 200, self.y + self.h / 2 + 300)
    def draw(self, c, res, t):
        a = ramp(t, self.t1 - 0.2, 0.5) * self.fade(t)
        if a <= 0: return
        x0, y0, w, h = self.x - self.w / 2, self.y - self.h / 2, self.w, self.h
        c.drawRRect(skia.RRect.MakeRectXY(skia.Rect.MakeXYWH(x0 - 120, y0 - 120, w + 240, h + 240), 40, 40), paint((24, 36, 69), .92 * a))
        ax = paint((245, 245, 240), .8 * a, stroke=14)
        c.drawLine(x0, y0 + h, x0 + w, y0 + h, ax); c.drawLine(x0, y0, x0, y0 + h, ax)
        sx = lambda k: x0 + w * k / self.N
        sy = lambda v: y0 + h - h * 0.95 * v / self.pm
        # smooth curve
        u = ease_out_cubic(ramp(t, self.t1, 1.6))
        path = skia.Path(); path.moveTo(sx(2), sy(0))
        for k, v in self.pts:
            if (k - 2) / (self.N - 2) <= u: path.lineTo(sx(k), sy(v))
        c.drawPath(path, paint((88, 196, 221), a, stroke=26))
        # staircase builds one prime at a time
        u3 = ramp(t, self.t3, 2.6)
        n_show = int(u3 * len(self.primes) + 0.999) if u3 > 0 else 0
        st = skia.Path(); st.moveTo(sx(0), sy(0)); cnt = 0
        for i, p in enumerate(self.primes[:n_show]):
            st.lineTo(sx(p), sy(cnt)); cnt += 1; st.lineTo(sx(p), sy(cnt))
        if n_show:
            st.lineTo(sx(self.primes[n_show - 1] + 3), sy(cnt))
            c.drawPath(st, paint((250, 229, 138), a, stroke=26))
            c.drawCircle(sx(self.primes[n_show - 1]), sy(cnt), 34, paint((250, 229, 138), a))
        draw_text(c, res, "SMOOTH CURVE", x0 + w * 0.62, y0 + h * 0.98 + 150 - h, 120, "label", (88, 196, 221), a * ramp(t, self.t1, .6), 0.05, "left")
        draw_text(c, res, "TRUE PRIMES", x0 + w * 0.05, y0 + 220, 120, "label", (250, 229, 138), a * ramp(t, self.t3, .6), 0.05, "left")
        draw_text(c, res, "PRIMES UP TO 50 · COMPUTED BY US", x0, y0 + h + 340, 100, "label", (245, 245, 240), .8 * a, 0.04, "left")
